import { useState, useEffect } from 'react'
import Navigation from './components/Navigation'
import Hero from './sections/Hero'
import About from './sections/About'
import WhyChooseUs from './sections/WhyChooseUs'
import Menu from './sections/Menu'
import Reviews from './sections/Reviews'
import Gallery from './sections/Gallery'
import Contact from './sections/Contact'
import Footer from './components/Footer'
import LoadingScreen from './components/LoadingScreen'
import './index.css'

function App() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <div className="relative bg-primary-black min-h-screen overflow-x-hidden">
      <Navigation />
      
      <main>
        <Hero />
        <About />
        <WhyChooseUs />
        <Menu />
        <Reviews />
        <Gallery />
        <Contact />
      </main>
      
      <Footer />
    </div>
  )
}

export default App
