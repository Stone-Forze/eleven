export default function Footer() {
  return (
    <footer className="bg-primary-black border-t border-primary-gold/20 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-2xl font-playfair font-bold gold-gradient mb-4">ELEVENS</h3>
            <p className="text-primary-cream/80">
              Fine dining experience in the heart of Gola Gokaran Nath
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-bold text-primary-gold mb-4">Quick Links</h4>
            <nav className="space-y-2">
              {['Home', 'About', 'Menu', 'Gallery', 'Contact'].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="block text-primary-cream/80 hover:text-primary-gold transition-colors"
                >
                  {item}
                </a>
              ))}
            </nav>
          </div>
          
          <div>
            <h4 className="text-lg font-bold text-primary-gold mb-4">Follow Us</h4>
            <div className="flex gap-4">
              {['facebook', 'instagram', 'twitter'].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="w-10 h-10 rounded-full glass-card flex items-center justify-center hover:scale-110 transition-transform"
                  aria-label={social}
                >
                  <span className="text-primary-gold text-xl">📱</span>
                </a>
              ))}
            </div>
          </div>
        </div>
        
        <div className="border-t border-primary-gold/20 pt-8 text-center text-primary-cream/60">
          <p>&copy; 2024 ELEVENS Restaurant. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
