import { motion } from 'framer-motion'

export default function About() {
  return (
    <section id="about" className="section-container bg-gradient-to-b from-primary-black to-primary-darkGray">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <h2 className="section-title">
          Our <span className="gold-gradient">Story</span>
        </h2>
        <p className="section-subtitle">
          A Journey of Flavor, Passion, and Excellence
        </p>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-6">
            <p className="text-lg text-primary-cream/90 leading-relaxed">
              Welcome to <span className="text-primary-gold font-semibold">ELEVENS</span>, 
              where culinary tradition meets contemporary innovation. Located in the heart 
              of Gola Gokaran Nath, we've been serving authentic flavors and unforgettable 
              dining experiences since our establishment.
            </p>
            
            <p className="text-lg text-primary-cream/90 leading-relaxed">
              Our master chefs craft each dish with precision, using only the finest 
              ingredients sourced from local farmers and trusted suppliers. Every plate 
              that leaves our kitchen is a testament to our commitment to quality and taste.
            </p>

            <p className="text-lg text-primary-cream/90 leading-relaxed">
              At ELEVENS, we believe dining is more than just a meal—it's an experience. 
              From our elegant ambiance to our attentive service, every detail is designed 
              to make your visit memorable.
            </p>

            <div className="flex flex-wrap gap-8 pt-6">
              <div className="glass-card px-6 py-4">
                <div className="text-4xl font-bold text-primary-gold mb-2">10+</div>
                <div className="text-primary-beige">Years Experience</div>
              </div>
              <div className="glass-card px-6 py-4">
                <div className="text-4xl font-bold text-primary-gold mb-2">50+</div>
                <div className="text-primary-beige">Menu Items</div>
              </div>
              <div className="glass-card px-6 py-4">
                <div className="text-4xl font-bold text-primary-gold mb-2">1000+</div>
                <div className="text-primary-beige">Happy Customers</div>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="glass-card p-2 aspect-square">
              <div className="w-full h-full bg-gradient-to-br from-primary-gold/20 to-primary-darkGray rounded-xl flex items-center justify-center">
                <svg className="w-32 h-32 text-primary-gold/40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-32 h-32 border-2 border-primary-gold/30 rounded-xl -z-10"></div>
            <div className="absolute -bottom-4 -left-4 w-32 h-32 border-2 border-primary-gold/30 rounded-xl -z-10"></div>
          </div>
        </div>
      </motion.div>
    </section>
  )
}
