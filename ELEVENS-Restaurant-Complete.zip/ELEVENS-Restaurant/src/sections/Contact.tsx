import { motion } from 'framer-motion'

export default function Contact() {
  return (
    <section id="contact" className="section-container bg-primary-darkGray">
      <h2 className="section-title">
        Get in <span className="gold-gradient">Touch</span>
      </h2>
      <p className="section-subtitle">
        Reserve Your Table or Reach Out to Us
      </p>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Contact Form */}
        <motion.div
          className="glass-card p-8"
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <form className="space-y-6">
            <div>
              <input
                type="text"
                placeholder="Your Name"
                className="w-full px-4 py-3 bg-primary-black/50 border border-primary-gold/30 rounded-lg text-primary-cream focus:outline-none focus:border-primary-gold transition-colors"
              />
            </div>
            <div>
              <input
                type="email"
                placeholder="Your Email"
                className="w-full px-4 py-3 bg-primary-black/50 border border-primary-gold/30 rounded-lg text-primary-cream focus:outline-none focus:border-primary-gold transition-colors"
              />
            </div>
            <div>
              <input
                type="tel"
                placeholder="Phone Number"
                className="w-full px-4 py-3 bg-primary-black/50 border border-primary-gold/30 rounded-lg text-primary-cream focus:outline-none focus:border-primary-gold transition-colors"
              />
            </div>
            <div>
              <textarea
                rows={4}
                placeholder="Your Message"
                className="w-full px-4 py-3 bg-primary-black/50 border border-primary-gold/30 rounded-lg text-primary-cream focus:outline-none focus:border-primary-gold transition-colors resize-none"
              />
            </div>
            <button type="submit" className="btn-primary w-full">
              Send Message
            </button>
          </form>
        </motion.div>

        {/* Contact Info */}
        <motion.div
          className="space-y-6"
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="glass-card p-6">
            <h3 className="text-2xl font-bold text-primary-gold mb-4">Visit Us</h3>
            <p className="text-primary-cream/90 leading-relaxed">
              Lakhimpur Rd, opposite Maya Hospital<br />
              Badal Nagar, Gola Gokaran Nath<br />
              Gola, Uttar Pradesh 262802
            </p>
          </div>

          <div className="glass-card p-6">
            <h3 className="text-2xl font-bold text-primary-gold mb-4">Call Us</h3>
            <a href="tel:08429891601" className="text-primary-cream/90 text-xl hover:text-primary-gold transition-colors">
              084298 91601
            </a>
          </div>

          <div className="glass-card p-6">
            <h3 className="text-2xl font-bold text-primary-gold mb-4">Opening Hours</h3>
            <div className="space-y-2 text-primary-cream/90">
              <p>Monday - Saturday: 11:00 AM - 11:00 PM</p>
              <p>Sunday: 12:00 PM - 10:00 PM</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
