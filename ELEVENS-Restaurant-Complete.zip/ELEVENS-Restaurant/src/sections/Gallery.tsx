import { motion } from 'framer-motion'

export default function Gallery() {
  return (
    <section id="gallery" className="section-container bg-gradient-to-b from-primary-black to-primary-darkGray">
      <h2 className="section-title">
        Our <span className="gold-gradient">Gallery</span>
      </h2>
      <p className="section-subtitle">
        A Visual Journey Through Our Culinary World
      </p>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {[...Array(8)].map((_, index) => (
          <motion.div
            key={index}
            className="glass-card p-2 aspect-square hover:scale-105 transition-transform duration-300 cursor-pointer"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <div className="w-full h-full bg-gradient-to-br from-primary-gold/20 to-primary-darkGray rounded-xl flex items-center justify-center">
              <svg className="w-16 h-16 text-primary-gold/40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
