import { motion } from 'framer-motion'
import { useState } from 'react'

const categories = ['All', 'Starters', 'Main Course', 'Desserts', 'Beverages']

const menuItems = [
  { category: 'Starters', name: 'Paneer Tikka', price: '₹250', description: 'Grilled cottage cheese with aromatic spices' },
  { category: 'Starters', name: 'Chicken Kebab', price: '₹300', description: 'Succulent chicken marinated in traditional spices' },
  { category: 'Main Course', name: 'Butter Chicken', price: '₹350', description: 'Creamy tomato-based chicken curry' },
  { category: 'Main Course', name: 'Dal Makhani', price: '₹280', description: 'Slow-cooked black lentils in rich gravy' },
  { category: 'Main Course', name: 'Biryani Special', price: '₹400', description: 'Aromatic basmati rice with tender meat' },
  { category: 'Desserts', name: 'Gulab Jamun', price: '₹120', description: 'Soft milk dumplings in rose-scented syrup' },
  { category: 'Desserts', name: 'Kulfi', price: '₹100', description: 'Traditional Indian ice cream' },
  { category: 'Beverages', name: 'Masala Chai', price: '₹60', description: 'Spiced Indian tea with aromatic herbs' },
]

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState('All')

  const filteredItems = activeCategory === 'All' 
    ? menuItems 
    : menuItems.filter(item => item.category === activeCategory)

  return (
    <section id="menu" className="section-container bg-gradient-to-b from-primary-black to-primary-darkGray">
      <h2 className="section-title">
        Our <span className="gold-gradient">Menu</span>
      </h2>
      <p className="section-subtitle">
        Discover Our Culinary Delights
      </p>

      {/* Category Filter */}
      <div className="flex flex-wrap justify-center gap-4 mb-12">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
              activeCategory === category
                ? 'bg-primary-gold text-primary-black'
                : 'glass-card text-primary-cream hover:border-primary-gold'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Menu Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredItems.map((item, index) => (
          <motion.div
            key={index}
            className="glass-card p-6 hover:scale-105 transition-transform duration-300"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <div className="flex justify-between items-start mb-3">
              <h3 className="text-2xl font-bold text-primary-cream">{item.name}</h3>
              <span className="text-2xl font-bold text-primary-gold">{item.price}</span>
            </div>
            <p className="text-primary-beige/80 mb-4">{item.description}</p>
            <span className="inline-block px-3 py-1 bg-primary-gold/20 text-primary-gold text-sm rounded-full">
              {item.category}
            </span>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
