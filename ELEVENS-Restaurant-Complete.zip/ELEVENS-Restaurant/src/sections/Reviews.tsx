import { motion } from 'framer-motion'

const reviews = [
  { name: 'Rajesh Kumar', rating: 5, text: 'Absolutely amazing food! The biryani was outstanding.', role: 'Food Enthusiast' },
  { name: 'Priya Sharma', rating: 4, text: 'Great ambiance and excellent service. Highly recommend!', role: 'Regular Customer' },
  { name: 'Amit Patel', rating: 5, text: 'Best restaurant in the area. Fresh ingredients, perfect taste.', role: 'Local Resident' },
]

export default function Reviews() {
  return (
    <section className="section-container bg-primary-darkGray">
      <h2 className="section-title">
        Customer <span className="gold-gradient">Reviews</span>
      </h2>
      <p className="section-subtitle">
        What Our Guests Say About Us
      </p>

      <div className="grid md:grid-cols-3 gap-8">
        {reviews.map((review, index) => (
          <motion.div
            key={index}
            className="glass-card p-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: index * 0.2 }}
          >
            <div className="flex gap-1 mb-4">
              {[...Array(review.rating)].map((_, i) => (
                <svg key={i} className="w-5 h-5 fill-primary-gold" viewBox="0 0 20 20">
                  <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                </svg>
              ))}
            </div>
            <p className="text-primary-cream/90 mb-6 italic">"{review.text}"</p>
            <div>
              <div className="font-bold text-primary-gold">{review.name}</div>
              <div className="text-sm text-primary-beige/70">{review.role}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
