import { motion } from 'framer-motion'

const features = [
  {
    icon: '👨‍🍳',
    title: 'Expert Chefs',
    description: 'Our master chefs bring years of culinary expertise'
  },
  {
    icon: '🌿',
    title: 'Fresh Ingredients',
    description: 'Locally sourced, premium quality ingredients daily'
  },
  {
    icon: '⭐',
    title: 'Premium Quality',
    description: 'Every dish crafted to perfection with attention to detail'
  },
  {
    icon: '🍽️',
    title: 'Diverse Menu',
    description: 'Authentic flavors from traditional to contemporary'
  }
]

export default function WhyChooseUs() {
  return (
    <section id="features" className="section-container bg-primary-darkGray">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <h2 className="section-title">
          Why <span className="gold-gradient">Choose Us</span>
        </h2>
        <p className="section-subtitle">
          Excellence in Every Detail
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="glass-card p-8 text-center hover:scale-105 transition-transform duration-300"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <div className="text-6xl mb-4">{feature.icon}</div>
              <h3 className="text-2xl font-bold text-primary-gold mb-3">{feature.title}</h3>
              <p className="text-primary-cream/80">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  )
}
